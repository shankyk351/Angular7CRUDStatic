import { Component, OnInit, ViewChild,ElementRef, Renderer2 } from '@angular/core';

@Component({
  selector: 'app-parent',
  templateUrl: './parent.component.html',
  styleUrls: ['./parent.component.scss']
})
export class ParentComponent implements OnInit {

  pInput: any = '';
  parentVal = 'parent data';
  @ViewChild('parentData') public par: any = 'hello himanshu';

  constructor(public el: ElementRef, public renderer: Renderer2) { }

  ngOnInit() {
    // console.log('par', this.par);
  }

  childDataFun(val){
    console.log('child data', val);
  }

  ngAfterContentInit(){
    // console.log('par content init', this.par);
  }

  ngAfterContentChecked(){
    // console.log('par content checked', this.par);
  }

  ngAfterViewInit(){
    // console.log('par init', this.par);
  }

  ngAfterViewChecked(){
    // console.log('par checked', this.par);
  }

}

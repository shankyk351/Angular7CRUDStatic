import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class TestService {

  constructor() { }

  testFunc(){
    return {
      firstName: 'himanshu',
      lastName: 'gupta'
    }
  }
}

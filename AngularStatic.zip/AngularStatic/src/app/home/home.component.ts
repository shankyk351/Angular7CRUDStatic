import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.scss']
})

// export interface User {
//     firstName:string;
//     lastName:string;
// }

export class HomeComponent implements OnInit {

  user = {
        firstName: 'Alice',
        lastName: 'Smith'
    };

  constructor() { }

  ngOnInit() {
  }

  

  changeUserName() {
      this.user.firstName = 'Bob';
  }

}

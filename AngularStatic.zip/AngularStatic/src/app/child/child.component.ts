import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';

@Component({
  selector: 'app-child',
  templateUrl: './child.component.html',
  styleUrls: ['./child.component.scss']
})
export class ChildComponent implements OnInit {

  @Input('parentData') parentData;
  @Output() child= new EventEmitter();
  constructor() { }

  logIt(data){
    // console.log(data);
  };

  ngOnInit() {
    this.logIt('hello');
    // console.log('parent data', this.parentData);
  }

  childFun(e){
    console.log(e.currentTarget.value);
    this.child.emit(e.currentTarget.value);
  }

  ngOnChanges(changes: ChildComponent){
    // console.log('changes', changes);
    // console.log('Previous Value', changes.parentData.previousValue);
    // console.log('Current Value', changes.parentData.currentValue);
    // console.log('on changes', this.parentData);
  }

  ngAfterViewInit(){
    // console.log('view init', this.parentData);
  }

  ngAfterViewChecked(){
    // console.log('view checked', this.parentData);
  }

  ngAfterContentInit(){
    // console.log('content init', this.parentData);
  }

  ngAfterContentChecked(){
    // console.log('content checked', this.parentData);
  }

  ngOnDestroy(){

  }

}
